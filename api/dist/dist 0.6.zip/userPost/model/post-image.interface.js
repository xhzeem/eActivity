"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=post-image.interface.js.map