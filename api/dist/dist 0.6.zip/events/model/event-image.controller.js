"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=event-image.controller.js.map