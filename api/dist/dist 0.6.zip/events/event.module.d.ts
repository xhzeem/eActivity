export declare class EventModule {
}
