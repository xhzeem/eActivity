export declare const hasRoles: (...hasRoles: string[]) => import("@nestjs/common").CustomDecorator<string>;
