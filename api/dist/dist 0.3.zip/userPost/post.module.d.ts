export declare class PostModule {
}
