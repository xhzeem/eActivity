"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=post-entry.interface.js.map