export declare class BlogModule {
}
