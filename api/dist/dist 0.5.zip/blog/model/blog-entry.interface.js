"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=blog-entry.interface.js.map